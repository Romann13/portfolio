[CmdletBinding(SupportsShouldProcess=$true)]
param (
    [Parameter(Mandatory=$true)]
    [string]$CsvPath, # Chemin vers create_user.csv

    [string]$BaseDataDir = "C:\UsersData",
    [string]$LogDir = "C:\Log"
)

# Configuration des logs
if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory | Out-Null }
$logFile = Join-Path $LogDir "CreationAD_$((Get-Date -Format 'yyyyMMdd')).log"

function Write-Log($Message, $Level = "INFO") {
    $entry = "$(Get-Date -Format 'HH:mm:ss') [$Level] $Message"
    $entry | Out-File -FilePath $logFile -Append
    Write-Host $entry -ForegroundColor (switch($Level) { "ERROR" {"Red"}; "SUCCESS" {"Green"}; "WARN" {"Yellow"}; default {"White"} })
}

if (-not (Test-Path $CsvPath)) { Write-Log "Fichier CSV introuvable." "ERROR"; return }

$users = Import-Csv -Path $CsvPath

foreach ($user in $users) {
    $Sam = $user.Login
    $UserFolder = Join-Path $BaseDataDir $Sam

    # Vérification existence
    if (Get-ADUser -Filter "SamAccountName -eq '$Sam'" -ErrorAction SilentlyContinue) {
        Write-Log "L'utilisateur $Sam existe deja." "WARN"
        continue
    }

    if ($PSCmdlet.ShouldProcess($Sam, "Creation compte AD et dossier personnel")) {
        try {
            # 1. Création du compte dans l'AD
            $Password = ConvertTo-SecureString "MotDePasse123!" -AsPlainText -Force
            New-ADUser -Name "$($user.Prenom) $($user.Nom)" -SamAccountName $Sam `
                       -Path "OU=$($user.OU),DC=rt,DC=local" -AccountPassword $Password `
                       -ChangePasswordAtLogon $true -Enabled $true -UserPrincipalName "$Sam@rt.local"
            
            # 2. Création du dossier et gestion des droits NTFS
            if (-not (Test-Path $UserFolder)) { 
                New-Item -Path $UserFolder -ItemType Directory | Out-Null 
                
                $acl = Get-Acl $UserFolder
                $acl.SetAccessRuleProtection($true, $false) # Coupe l'héritage pour la sécurité
                
                # Propriété et contrôle total pour l'utilisateur
                $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("rt\$Sam", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
                $acl.AddAccessRule($rule)
                Set-Acl $UserFolder $acl
            }
            Write-Log "Utilisateur $Sam cree avec succes (AD + Dossier)." "SUCCESS"
        } catch {
            Write-Log "Erreur lors de la creation de $Sam : $($_.Exception.Message)" "ERROR"
        }
    }
}