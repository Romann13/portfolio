[CmdletBinding(SupportsShouldProcess=$true)]
param (
    [Parameter(Mandatory=$true)]
    [string]$CsvPath, # Chemin vers supp_list.csv

    [string]$BaseDataDir = "C:\UsersData",
    [string]$ArchiveDir = "C:\Archives",
    [string]$LogDir = "C:\Log"
)

# Configuration des logs
if (-not (Test-Path $LogDir)) { New-Item -Path $LogDir -ItemType Directory | Out-Null }
$logFile = Join-Path $LogDir "SuppressionAD_$((Get-Date -Format 'yyyyMMdd')).log"

function Write-Log($Message, $Level = "INFO") {
    $entry = "$(Get-Date -Format 'HH:mm:ss') [$Level] $Message"
    $entry | Out-File -FilePath $logFile -Append
    Write-Host $entry -ForegroundColor (switch($Level) { "ERROR" {"Red"}; "SUCCESS" {"Green"}; default {"White"} })
}

if (-not (Test-Path $CsvPath)) { Write-Log "Fichier CSV introuvable." "ERROR"; return }

$users = Import-Csv -Path $CsvPath
$dateStamp = Get-Date -Format "yyyyMMdd"

foreach ($user in $users) {
    $Sam = $user.Login
    $UserFolder = Join-Path $BaseDataDir $Sam

    # Vérification existence AD
    if (-not (Get-ADUser -Filter "SamAccountName -eq '$Sam'" -ErrorAction SilentlyContinue)) {
        Write-Log "Utilisateur $Sam introuvable dans l'AD." "WARN"
        continue
    }

    if ($PSCmdlet.ShouldProcess($Sam, "Archivage des donnees et suppression du compte")) {
        try {
            # 1. Archivage du dossier personnel en ZIP
            if (Test-Path $UserFolder) {
                if (-not (Test-Path $ArchiveDir)) { New-Item $ArchiveDir -ItemType Directory | Out-Null }
                
                $zipFile = Join-Path $ArchiveDir "$($Sam)_$($dateStamp).zip"
                Compress-Archive -Path $UserFolder -DestinationPath $zipFile -Force
                Remove-Item $UserFolder -Recurse -Force
                Write-Log "Dossier de $Sam archive vers $zipFile." "INFO"
            }

            # 2. Suppression du compte Active Directory
            Remove-ADUser -Identity $Sam -Confirm:$false
            Write-Log "Utilisateur $Sam supprime definitivement." "SUCCESS"
        } catch {
            Write-Log "Erreur lors de la suppression de $Sam : $($_.Exception.Message)" "ERROR"
        }
    }
}